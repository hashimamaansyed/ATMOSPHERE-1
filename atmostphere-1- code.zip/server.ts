import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Mock data generator
  const getMockData = () => {
    const now = new Date();
    const temp = (24 + Math.random() * 2).toFixed(1);
    const hum = (45 + Math.random() * 5).toFixed(1);
    const press = (1012 + Math.random() * 2).toFixed(1);

    // Generate trend data (last 60 mins)
    const trend = Array.from({ length: 60 }, (_, i) => ({
      time: i,
      temp: (24 + Math.sin(i / 10) + Math.random()).toFixed(1),
      humidity: (45 + Math.cos(i / 10) + Math.random()).toFixed(1),
      pressure: (1012 + Math.random()).toFixed(1)
    }));

    return {
      timestamp: now.toISOString(),
      connected: true,
      status: "active",
      sensors: {
        temperature: temp,
        humidity: hum,
        pressure: press,
      },
      extendedStats: {
        tempAvg: (parseFloat(temp) - 0.2).toFixed(1),
        humidityAvg: (parseFloat(hum) + 1.5).toFixed(1),
        pressureAvg: (parseFloat(press) - 0.5).toFixed(1),
        history: trend
      },
      weather: {
        city: "Chennai",
        temp: (32 + Math.random() * 3).toFixed(1),
        humidity: (65 + Math.random() * 10).toFixed(1),
        pressure: (1008 + Math.random() * 2).toFixed(1),
        uvIndex: (8 + Math.random() * 2).toFixed(1),
        windSpeed: (12 + Math.random() * 5).toFixed(1),
      },
      system: {
        cpuTemp: (55 + Math.random() * 15).toFixed(1),
        diskUsage: (42 + Math.random() * 2).toFixed(1),
        fanActive: false, // Will be calculated below
      },
    };
  };

  // API endpoint
  app.get("/api/data", (req, res) => {
    const data = getMockData();
    // Simulate fan control logic
    if (parseFloat(data.system.cpuTemp) > 65) {
      data.system.fanActive = true;
    }
    res.json(data);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
