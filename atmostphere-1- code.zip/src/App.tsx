import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Thermometer, 
  Droplets, 
  Wind, 
  Sun, 
  Cpu, 
  HardDrive, 
  Activity,
  RefreshCw,
  AlertTriangle,
  Compass,
  Clock
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  ResponsiveContainer, 
  YAxis, 
  XAxis 
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
interface HUDData {
  timestamp: string;
  connected: boolean;
  status: string;
  sensors: {
    temperature: string;
    humidity: string;
    pressure: string;
  };
  weather: {
    city: string;
    temp: string;
    humidity: string;
    pressure: string;
    uvIndex: string;
    windSpeed: string;
  };
  system: {
    cpuTemp: string;
    diskUsage: string;
    fanActive: boolean;
  };
  extendedStats: {
    tempAvg: string;
    humidityAvg: string;
    pressureAvg: string;
    history: { time: number; temp: string; humidity: string; pressure: string }[];
  };
}

// --- Components ---

const Panel = ({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) => (
  <div className={cn("panel", className)}>
    <div className="corners tl" />
    <div className="corners tr" />
    <div className="corners bl" />
    <div className="corners br" />
    <span className="panel-header">{title}</span>
    {children}
  </div>
);

const RadialDisplay = ({ value, city, uvIndex }: { value: string; city: string; uvIndex: string }) => {
  const uvValue = parseFloat(uvIndex);
  const uvPercent = Math.min((uvValue / 12) * 100, 100); // UV index usually 0-11+

  return (
    <div className="flex flex-col items-center justify-center relative">
      <div className="radial-container">
        <div className="absolute inset-0 border border-hud-dim rounded-full opacity-20" />
        <div className="pulse-ring">
          <div className="text-[12px] tracking-[3px]">TEMP_EXT</div>
          <div className="text-[84px] font-black leading-none hud-glow">{Math.round(parseFloat(value))}&deg;</div>
          <div className="text-[14px] tracking-[2px] mt-[10px]">{city.toUpperCase()}_INDIA</div>
        </div>
        
        {/* UV Index Indicator */}
        <div className="absolute -right-4 top-1/2 -translate-y-1/2 flex flex-col items-center gap-1">
          <div className="text-[8px] font-bold">UV_IDX</div>
          <div className="w-1.5 h-24 bg-hud-yellow/10 border border-hud-yellow/30 relative overflow-hidden">
            <motion.div 
              className="absolute bottom-0 left-0 right-0 bg-hud-yellow"
              initial={{ height: 0 }}
              animate={{ height: `${uvPercent}%` }}
              transition={{ duration: 1 }}
            />
          </div>
          <div className="text-[10px] font-bold">{uvIndex}</div>
        </div>

        {/* Tick marks around ring */}
        <div className="absolute top-[10px] text-[8px]">MAX: 34&deg;</div>
        <div className="absolute bottom-[10px] text-[8px]">MIN: 26&deg;</div>
      </div>
      <div className="mt-[30px] text-[11px] text-center">
        SENSING_ENGINE_STATUS: <span className="text-white">[CONTINUOUS_POLLING]</span>
      </div>
    </div>
  );
};

const ClimateSection = ({ title, data }: { title: string; data: Record<string, string> }) => (
  <div className="climate-card">
    <div className="text-[12px] mb-2 border-b border-hud-yellow">{title}</div>
    <div className="climate-grid">
      {Object.entries(data).map(([key, val]) => (
        <div key={key} className="mini-stat">
          <span className="lab">{key}</span>
          <span className="val">{val}</span>
        </div>
      ))}
    </div>
  </div>
);

const LogTerminal = ({ logs }: { logs: string[] }) => (
  <div className="footer-terminal">
    {logs.map((log, i) => (
      <div key={i} className="log-entry">
        <span className="log-ts">[{new Date().toLocaleTimeString([], { hour12: false })}]</span>
        {log}
        {i === logs.length - 1 && <span className="cursor-block" />}
      </div>
    ))}
  </div>
);

const DeepDive = ({ data, onBack }: { data: HUDData; onBack: () => void }) => {
  const isDisconnected = !data.connected;

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className={cn(
        "w-full h-full flex flex-col gap-6 transition-all duration-1000",
        isDisconnected ? "grayscale opacity-50" : "grayscale-0 opacity-100"
      )}
    >
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex flex-col">
          <h2 className={cn(
            "text-cyber-cyan text-2xl font-bold cyan-glow tracking-tighter",
            isDisconnected && "animate-pulse"
          )}>
            {isDisconnected ? "SEARCHING_FOR_HARDWARE..." : "BME280 // DEEP-DIVE"}
          </h2>
          <span className="text-off-white/50 text-xs">EXTENDED SENSOR ANALYTICS // 60M WINDOW</span>
        </div>
        <button 
          onClick={onBack}
          className="neu-flat px-6 py-2 rounded-lg border border-white/10 text-off-white hover:text-cyber-cyan transition-colors text-sm font-bold"
        >
          &lt; BACK_TO_HUD
        </button>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-2 gap-8 flex-grow">
        {/* Left: Primary Gauges */}
        <div className="flex flex-col gap-6">
          <div className="grid grid-cols-2 gap-6">
            {/* Temp Gauge */}
            <div className="neu-card flex flex-col items-center justify-center gap-4 aspect-square">
              <div className="relative w-32 h-32 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full neu-pressed" />
                <motion.div 
                  className={cn(
                    "absolute inset-2 rounded-full border-2",
                    isDisconnected ? "border-hud-yellow/40" : "border-cyber-cyan/20"
                  )}
                  animate={isDisconnected ? { 
                    boxShadow: ["0 0 0px #FFCC00", "0 0 15px #FFCC00", "0 0 0px #FFCC00"],
                    borderColor: ["rgba(255,204,0,0.2)", "rgba(255,204,0,0.6)", "rgba(255,204,0,0.2)"]
                  } : {}}
                  transition={isDisconnected ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : {}}
                />
                <div className="flex flex-col items-center">
                  <span className="text-cyber-cyan text-3xl font-black cyan-glow">
                    {isDisconnected ? "00.0" : data.sensors.temperature}°
                  </span>
                  <span className="text-[8px] text-off-white/50">INDOOR_TEMP</span>
                </div>
              </div>
              <div className="flex gap-4 text-[10px]">
                <div className="flex flex-col items-center">
                  <span className="text-off-white/40">MIN</span>
                  <span className="text-off-white">{isDisconnected ? "--.-" : "24.1°"}</span>
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-off-white/40">MAX</span>
                  <span className="text-off-white">{isDisconnected ? "--.-" : "26.8°"}</span>
                </div>
              </div>
            </div>

            {/* Humidity Gauge */}
            <div className="neu-card flex flex-col items-center justify-center gap-4 aspect-square">
              <div className="relative w-32 h-32 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full neu-pressed" />
                <motion.div 
                  className={cn(
                    "absolute inset-2 rounded-full border-2",
                    isDisconnected ? "border-hud-yellow/40" : "border-cyber-cyan/20"
                  )}
                  animate={isDisconnected ? { 
                    boxShadow: ["0 0 0px #FFCC00", "0 0 15px #FFCC00", "0 0 0px #FFCC00"],
                    borderColor: ["rgba(255,204,0,0.2)", "rgba(255,204,0,0.6)", "rgba(255,204,0,0.2)"]
                  } : {}}
                  transition={isDisconnected ? { duration: 2, repeat: Infinity, ease: "easeInOut" } : {}}
                />
                <div className="flex flex-col items-center">
                  <span className="text-cyber-cyan text-3xl font-black cyan-glow">
                    {isDisconnected ? "00.0" : data.sensors.humidity}%
                  </span>
                  <span className="text-[8px] text-off-white/50">INDOOR_HUMID</span>
                </div>
              </div>
              <div className="text-[10px] text-cyber-cyan/80 font-bold tracking-widest">
                {isDisconnected ? "STATUS: OFFLINE" : "COMFORT: OPTIMAL"}
              </div>
            </div>
          </div>

          {/* Diagnostics Panel */}
          <div className="neu-card flex-grow flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div className="flex flex-col">
                <span className="text-[10px] text-off-white/50">SYSTEM_DIAGNOSTICS</span>
                <span className={cn(
                  "font-bold tracking-tighter",
                  isDisconnected ? "text-hud-yellow" : "text-cyber-cyan cyan-glow"
                )}>
                  {isDisconnected ? "SEARCHING FOR SENSOR..." : "SENSOR DETECTED @ 0x77"}
                </span>
              </div>
              <div className={cn(
                "px-2 py-1 border rounded text-[10px] font-bold",
                isDisconnected 
                  ? "bg-hud-yellow/10 border-hud-yellow/30 text-hud-yellow animate-pulse" 
                  : "bg-cyber-cyan/10 border-cyber-cyan/30 text-cyber-cyan"
              )}>
                {isDisconnected ? "SEARCHING" : "PASS"}
              </div>
            </div>
            <div className="flex justify-between items-end">
              <div className="flex flex-col">
                <span className="text-[8px] text-off-white/40 uppercase">CPU_CORE_TEMP</span>
                <span className="text-xl font-bold text-off-white">{data.system.cpuTemp}°C</span>
              </div>
              <div className="flex flex-col text-right">
                <span className="text-[8px] text-off-white/40 uppercase">SENSOR_CALIBRATION</span>
                <span className={cn(
                  "text-sm font-bold",
                  isDisconnected ? "text-hud-yellow" : "text-cyber-cyan"
                )}>
                  {isDisconnected ? "WAITING..." : "STABLE_0x77"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Trends & History */}
        <div className="flex flex-col gap-6">
          {/* Pressure & CO2 */}
          <div className="neu-card flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-2 h-2 rounded-full",
                  isDisconnected ? "bg-hud-yellow/30" : "bg-hud-yellow animate-pulse"
                )} />
                <span className="text-xs text-off-white/70">BAROMETRIC_PRESSURE</span>
              </div>
              <span className="text-cyber-cyan font-bold cyan-glow">
                {isDisconnected ? "----.-" : data.sensors.pressure} hPa
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-hud-yellow rounded-full" />
                <span className="text-xs text-off-white/70">CALCULATED_CO2</span>
              </div>
              <span className="text-off-white font-bold">{isDisconnected ? "---" : "412"} ppm</span>
            </div>
          </div>

          {/* History Graph */}
          <div className="neu-card flex-grow flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <span className="text-[10px] text-off-white/50">60-MINUTE_TEMP_TREND</span>
              <span className="text-[10px] text-cyber-cyan font-bold">
                {isDisconnected ? "AVG: --.-°C" : `AVG: ${data.extendedStats.tempAvg}°C`}
              </span>
            </div>
            <div className="flex-grow relative">
              <div className="absolute inset-0 opacity-10 pointer-events-none">
                <div className="w-full h-full" style={{ background: 'repeating-linear-gradient(90deg, transparent, transparent 19px, rgba(0,255,255,0.2) 19px, rgba(0,255,255,0.2) 20px)' }} />
              </div>
              {!isDisconnected && (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.extendedStats.history}>
                    <Line 
                      type="monotone" 
                      dataKey="temp" 
                      stroke="#00FFFF" 
                      strokeWidth={2} 
                      dot={false}
                      isAnimationActive={false}
                    />
                    <YAxis hide domain={['dataMin - 1', 'dataMax + 1']} />
                  </LineChart>
                </ResponsiveContainer>
              )}
              {isDisconnected && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[10px] text-off-white/20 tracking-[4px] animate-pulse">NO_DATA_STREAM</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default function App() {
  const [data, setData] = useState<HUDData | null>(null);
  const [cpuHistory, setCpuHistory] = useState<{ time: string; value: number }[]>([]);
  const [logs, setLogs] = useState<string[]>(["INITIALIZING SENSORS... OK"]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'hud' | 'deep-dive'>('hud');

  const fetchData = async () => {
    try {
      const res = await fetch('/api/data');
      const json = await res.json();
      
      // Handle connection transition logs
      setData(prev => {
        if (prev && !prev.connected && json.connected) {
          setLogs(l => [...l, ">>> SENSOR DETECTED AT 0x77", ">>> SYSTEM ONLINE // DATA FLOW ACTIVE"].slice(-10));
        } else if (prev && prev.connected && !json.connected) {
          setLogs(l => [...l, "!!! WARNING: SENSOR DISCONNECTED", "!!! SEARCHING FOR HARDWARE..."].slice(-10));
        }
        return json;
      });

      setCpuHistory(prev => {
        const next = [...prev, { time: json.timestamp, value: parseFloat(json.system.cpuTemp) }];
        return next.slice(-20);
      });
      
      if (loading) {
        setLogs(prev => [...prev, "FETCHING EXTERNAL DATA... 200 OK", "REFRESHING ALL MODULES... SUCCESS"]);
        setLoading(false);
      } else if (!json.connected) {
        setLogs(prev => {
          const lastLog = prev[prev.length - 1];
          if (lastLog !== "WAITING FOR SENSOR...") {
            return [...prev, "WAITING FOR SENSOR..."].slice(-10);
          }
          return prev;
        });
      }
    } catch (err) {
      console.error("Fetch error:", err);
      setLogs(prev => [...prev, "ERROR: DATA FETCH FAILED"].slice(-5));
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 2000); // 2 second polling for real-time feel
    return () => clearInterval(interval);
  }, []);

  if (!data) return (
    <div className="flex items-center justify-center h-screen bg-black text-hud-yellow">
      <div className="flex flex-col items-center gap-4">
        <RefreshCw className="animate-spin" size={48} />
        <div className="text-xl tracking-widest uppercase hud-glow">Initializing ATMOSTPHERE-1...</div>
      </div>
    </div>
  );

  return (
    <div className="w-[1024px] h-[768px] bg-hud-bg border-[4px] border-hud-yellow p-5 flex flex-col relative overflow-hidden mx-auto my-auto select-none">
      <AnimatePresence mode="wait">
        {view === 'hud' ? (
          <motion.div 
            key="hud"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.02 }}
            className="flex flex-col h-full"
          >
            {/* Header */}
            <header className="flex justify-between items-end border-b-2 border-hud-yellow pb-[10px] mb-5">
              <div className="flex flex-col gap-2">
                <h1 className="text-[32px] tracking-[4px] hud-glow font-bold">ATMOSTPHERE-1 // V.2.04</h1>
                <div className="flex gap-[15px] text-[12px]">
                  <span>CORE: STABLE</span>
                  <span>I2C: 0X77</span>
                  <span>
                    FAN: {data.system.fanActive ? "ACTIVE" : "STANDBY"}
                  </span>
                  <span>UPLINK: OK</span>
                </div>
              </div>
              <div className="flex items-end gap-6">
                <button 
                  onClick={() => setView('deep-dive')}
                  className="border border-hud-yellow px-4 py-1 text-[12px] hover:bg-hud-yellow hover:text-black transition-all font-bold tracking-widest"
                >
                  [ VIEW_DETAILS ]
                </button>
                <div className="text-right">
                  <div className="text-[24px] font-bold">{new Date().toLocaleTimeString([], { hour12: false })}</div>
                  <div className="text-[12px] opacity-70">{new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }).toUpperCase()} // {data.weather.city.toUpperCase()}</div>
                </div>
              </div>
            </header>

            {/* Main Grid */}
            <div className="grid grid-cols-[280px_1fr_280px] gap-5 flex-grow">
              {/* Left: Diagnostics */}
              <Panel title="SYSTEM.DIAGNOSTICS">
                <div className="flex flex-col gap-5">
                  <div className="stat-block">
                    <span className="text-[10px] opacity-80 block mb-[5px]">CPU THERMAL LOAD</span>
                    <div className="text-[24px] font-bold flex items-baseline gap-[5px]">
                      {data.system.cpuTemp} <span className="text-[14px]">&deg;C</span>
                    </div>
                    <div className="waveform" />
                  </div>

                  <div className="stat-block">
                    <span className="text-[10px] opacity-80 block mb-[5px]">DISK UTILIZATION</span>
                    <div className="text-[24px] font-bold flex items-baseline gap-[5px]">
                      {data.system.diskUsage} <span className="text-[14px]">%</span>
                    </div>
                    <div className="h-2 border border-hud-yellow mt-[10px] relative">
                      <motion.div 
                        className="h-full bg-hud-yellow"
                        initial={{ width: 0 }}
                        animate={{ width: `${data.system.diskUsage}%` }}
                      />
                    </div>
                  </div>

                  <div className="stat-block mt-10">
                    <span className="text-[10px] opacity-80 block mb-[5px]">BME280 SENSOR DATA</span>
                    <div className="text-[12px] leading-[1.6] border-l-2 border-hud-yellow pl-[10px]">
                      ADDR: 0x77 [I2C]<br />
                      REFRESH: 30000ms<br />
                      CALIBRATION: PASS
                    </div>
                  </div>
                </div>
              </Panel>

              {/* Center: Main Display */}
              <RadialDisplay value={data.weather.temp} city={data.weather.city} uvIndex={data.weather.uvIndex} />

              {/* Right: Environmental */}
              <Panel title="ENV.MONITORING">
                <ClimateSection 
                  title="INDOOR_CLIMATE" 
                  data={{
                    "TEMP": `${data.sensors.temperature}°`,
                    "HUMID": `${data.sensors.humidity}%`,
                    "PRESS": data.sensors.pressure,
                    "CO2": "412"
                  }} 
                />
                <ClimateSection 
                  title="OUTDOOR_ENV" 
                  data={{
                    "WIND": `${data.weather.windSpeed}KM`,
                    "UV IDX": data.weather.uvIndex,
                    "PRESS": data.weather.pressure,
                    "PRECIP": "0%",
                    "VIS": "10K"
                  }} 
                />
                <div className="text-[10px] opacity-60 mt-5">
                  DATA_SRC: OPENWEATHERMAP_ONE_CALL<br />
                  LAT: 13.08 / LON: 80.27
                </div>
              </Panel>
            </div>

            {/* Footer */}
            <LogTerminal logs={logs} />
          </motion.div>
        ) : (
          <DeepDive data={data} onBack={() => setView('hud')} />
        )}
      </AnimatePresence>
    </div>
  );
}
