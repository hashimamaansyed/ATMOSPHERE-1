import time
import json
import psutil
import RPi.GPIO as GPIO
from flask import Flask, jsonify
from smbus2 import SMBus
import bme280
import requests

app = Flask(__name__)

# --- CONFIGURATION ---
BME280_ADDRESS = 0x77
BUS_NUMBER = 1
FAN_PIN = 18
OPENWEATHER_API_KEY = "YOUR_API_KEY_HERE"
LAT = 13.08
LON = 80.27

# --- DATA HISTORY ---
history = {
    "temp": [],
    "humidity": [],
    "pressure": []
}
MAX_HISTORY = 60 # 60 minutes if polled every minute

def update_history(new_data):
    history["temp"].append(new_data["temperature"])
    history["humidity"].append(new_data["humidity"])
    history["pressure"].append(new_data["pressure"])
    
    if len(history["temp"]) > MAX_HISTORY:
        history["temp"].pop(0)
        history["humidity"].pop(0)
        history["pressure"].pop(0)

def get_averages():
    if not history["temp"]:
        return {"tempAvg": 0, "humidityAvg": 0, "pressureAvg": 0}
    
    return {
        "tempAvg": round(sum(history["temp"]) / len(history["temp"]), 1),
        "humidityAvg": round(sum(history["humidity"]) / len(history["humidity"]), 1),
        "pressureAvg": round(sum(history["pressure"]) / len(history["pressure"]), 1),
        "history": [{"time": i, "temp": t, "humidity": h, "pressure": p} 
                    for i, (t, h, p) in enumerate(zip(history["temp"], history["humidity"], history["pressure"]))]
    }

# --- HARDWARE SETUP ---
GPIO.setmode(GPIO.BCM)
GPIO.setup(FAN_PIN, GPIO.OUT)

bus = None
calibration_params = None
sensor_connected = False

def init_sensor():
    global bus, calibration_params, sensor_connected
    try:
        if bus is None:
            bus = SMBus(BUS_NUMBER)
        calibration_params = bme280.load_calibration_params(bus, BME280_ADDRESS)
        sensor_connected = True
        print("BME280 Initialized Successfully")
    except Exception as e:
        sensor_connected = False
        print(f"BME280 Initialization Failed: {e}")

# Initial attempt
init_sensor()

def get_bme280_data():
    global sensor_connected
    if not sensor_connected:
        init_sensor()
        time.sleep(1) # Safety delay between attempts
        if not sensor_connected:
            return None

    try:
        data = bme280.sample(bus, BME280_ADDRESS, calibration_params)
        return {
            "temperature": round(data.temperature, 1),
            "humidity": round(data.humidity, 1),
            "pressure": round(data.pressure, 1)
        }
    except Exception as e:
        print(f"BME280 Read Error: {e}")
        sensor_connected = False # Reset on failure
        return None

def get_weather_data():
    try:
        url = f"https://api.openweathermap.org/data/3.0/onecall?lat={LAT}&lon={LON}&exclude=minutely,hourly,daily,alerts&units=metric&appid={OPENWEATHER_API_KEY}"
        response = requests.get(url)
        data = response.json()
        current = data.get("current", {})
        return {
            "city": "Chennai",
            "temp": round(current.get("temp", 0), 1),
            "humidity": current.get("humidity", 0),
            "pressure": current.get("pressure", 0),
            "uvIndex": current.get("uvi", 0),
            "windSpeed": round(current.get("wind_speed", 0), 1)
        }
    except Exception as e:
        print(f"Weather API Error: {e}")
        return {"city": "Chennai", "temp": 0, "humidity": 0, "pressure": 0, "uvIndex": 0, "windSpeed": 0}

def get_system_health():
    # CPU Temp
    try:
        with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
            cpu_temp = int(f.read()) / 1000.0
    except:
        cpu_temp = 0
    
    # Disk Usage
    disk = psutil.disk_usage('/')
    
    # Fan Control
    fan_active = False
    if cpu_temp > 65:
        GPIO.output(FAN_PIN, GPIO.HIGH)
        fan_active = True
    else:
        GPIO.output(FAN_PIN, GPIO.LOW)
        fan_active = False
        
    return {
        "cpuTemp": round(cpu_temp, 1),
        "diskUsage": round(disk.percent, 1),
        "fanActive": fan_active
    }

@app.route('/data')
def data():
    sensor_data = get_bme280_data()
    
    if sensor_data:
        update_history(sensor_data)
        status = "active"
        connected = True
    else:
        status = "searching"
        connected = False
        sensor_data = {"temperature": 0, "humidity": 0, "pressure": 0}

    return jsonify({
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "connected": connected,
        "status": status,
        "sensors": sensor_data,
        "extendedStats": get_averages(),
        "weather": get_weather_data(),
        "system": get_system_health()
    })

if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=5000)
    finally:
        GPIO.cleanup()
